export type QueryValue = string | number | boolean | null | undefined;
export type QueryParams = Record<string, QueryValue | QueryValue[]>;

export type ApiRequestConfig = Omit<RequestInit, "body"> & {
  params?: QueryParams;
};

export type ApiEnvelope<T = unknown> = {
  success?: boolean;
  message?: string;
  error?: string;
  errorMessage?: string;
  data?: T;
  totalRecords?: number;
  page?: number;
  limit?: number;
  totalPages?: number;
  [key: string]: unknown;
};

export const SERVER_PORT = "3001";

function readEnv(name: string): string {
  const env = (import.meta as unknown as { env?: Record<string, string | undefined> }).env || {};
  return String(env[name] || "").trim();
}

const configuredApiBaseUrl = readEnv("VITE_API_BASE_URL").replace(/\/$/, "");

export const API_BASE_URL = configuredApiBaseUrl || `http://localhost:${SERVER_PORT}`;

const TOKEN_STORAGE_KEYS = [
  "ema-access-token",
  "ema-token",
  "accessToken",
  "token",
  "authToken",
  "ema-auth-token",
  "ema_access_token",
  "jwt",
];

const AUTH_STORAGE_KEYS = [
  "ema-auth",
  "auth",
  "user",
  "ema-user",
  "currentUser",
  "authUser",
  "ema-current-user",
];

function safeParseJson<T>(value: string | null): T | null {
  if (!value) return null;
  try {
    return JSON.parse(value) as T;
  } catch {
    return null;
  }
}

function readStorage(key: string) {
  if (typeof window === "undefined") return "";
  return window.localStorage.getItem(key) || window.sessionStorage.getItem(key) || "";
}

export function getStoredToken() {
  for (const key of TOKEN_STORAGE_KEYS) {
    const value = readStorage(key);
    if (value && value.trim()) return value.trim();
  }

  for (const key of AUTH_STORAGE_KEYS) {
    const authRecord = safeParseJson<{
      token?: string;
      accessToken?: string;
      authToken?: string;
      data?: { token?: string; accessToken?: string; authToken?: string };
      user?: { token?: string; accessToken?: string; authToken?: string };
    }>(readStorage(key));

    const token =
      authRecord?.accessToken ||
      authRecord?.token ||
      authRecord?.authToken ||
      authRecord?.data?.accessToken ||
      authRecord?.data?.token ||
      authRecord?.data?.authToken ||
      authRecord?.user?.accessToken ||
      authRecord?.user?.token ||
      authRecord?.user?.authToken ||
      "";

    if (token && token.trim()) return token.trim();
  }

  return "";
}

function appendParams(url: URL, params?: QueryParams) {
  if (!params) return;

  Object.entries(params).forEach(([key, rawValue]) => {
    if (Array.isArray(rawValue)) {
      rawValue.forEach((value) => {
        if (value !== undefined && value !== null && String(value).trim() !== "") {
          url.searchParams.append(key, String(value));
        }
      });
      return;
    }

    if (rawValue !== undefined && rawValue !== null && String(rawValue).trim() !== "") {
      url.searchParams.set(key, String(rawValue));
    }
  });
}

export function buildApiUrl(path: string, params?: QueryParams) {
  if (/^https?:\/\//i.test(path)) {
    const externalUrl = new URL(path);
    appendParams(externalUrl, params);
    return externalUrl.toString();
  }

  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  const url = new URL(`${API_BASE_URL}${normalizedPath}`);
  appendParams(url, params);
  return url.toString();
}

async function parseResponse(response: Response) {
  const contentType = response.headers.get("content-type") || "";
  const text = await response.text();
  if (!text) return {};

  if (contentType.includes("application/json")) {
    try {
      return JSON.parse(text);
    } catch {
      return {};
    }
  }

  try {
    return JSON.parse(text);
  } catch {
    return { data: text };
  }
}

export async function request<T = any>(
  method: string,
  path: string,
  data?: unknown,
  config: ApiRequestConfig = {}
): Promise<T> {
  const token = getStoredToken();
  const isFormData = typeof FormData !== "undefined" && data instanceof FormData;
  const headers = new Headers(config.headers || {});

  if (!isFormData && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  if (isFormData && headers.get("Content-Type")?.includes("multipart/form-data")) {
    headers.delete("Content-Type");
  }

  if (token && !headers.has("Authorization")) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  const response = await fetch(buildApiUrl(path, config.params), {
    ...config,
    method,
    credentials: config.credentials || "include",
    headers,
    body:
      method === "GET" || method === "HEAD"
        ? undefined
        : isFormData
          ? (data as BodyInit)
          : data !== undefined
            ? JSON.stringify(data)
            : undefined,
  });

  const payload = await parseResponse(response);

  if (!response.ok) {
    const message =
      payload?.message ||
      payload?.error ||
      payload?.errorMessage ||
      payload?.status ||
      `Request failed with status ${response.status}`;

    const error = new Error(message);
    (error as Error & { response?: { status: number; data: unknown } }).response = {
      status: response.status,
      data: payload,
    };
    throw error;
  }

  return payload as T;
}

export async function apiRequest<T = any>(path: string, config: ApiRequestConfig & { method?: string; body?: BodyInit | string | null } = {}) {
  const method = (config.method || "GET").toUpperCase();
  const body = config.body;
  const requestConfig: ApiRequestConfig = { ...config };
  delete (requestConfig as Record<string, unknown>).method;
  delete (requestConfig as Record<string, unknown>).body;

  const data =
    body instanceof FormData
      ? body
      : typeof body === "string"
        ? safeParseJson(body) ?? body
        : body ?? undefined;

  return request<T>(method, path, data, requestConfig);
}

export function unwrapData<T = any>(payload: any, emptyValue?: T): T {
  if (payload === undefined || payload === null) return emptyValue as T;
  if (payload?.data !== undefined) return payload.data as T;
  return payload as T;
}

export function unwrapArray<T = any>(payload: any): T[] {
  if (Array.isArray(payload)) return payload as T[];
  if (Array.isArray(payload?.data)) return payload.data as T[];
  if (Array.isArray(payload?.data?.data)) return payload.data.data as T[];
  if (Array.isArray(payload?.rows)) return payload.rows as T[];
  if (Array.isArray(payload?.reports)) return payload.reports as T[];
  if (Array.isArray(payload?.recordset)) return payload.recordset as T[];
  return [];
}

export const api = {
  get<T = any>(path: string, config: ApiRequestConfig = {}) {
    return request<T>("GET", path, undefined, config);
  },

  post<T = any>(path: string, data?: unknown, config: ApiRequestConfig = {}) {
    return request<T>("POST", path, data, config);
  },

  put<T = any>(path: string, data?: unknown, config: ApiRequestConfig = {}) {
    return request<T>("PUT", path, data, config);
  },

  patch<T = any>(path: string, data?: unknown, config: ApiRequestConfig = {}) {
    return request<T>("PATCH", path, data, config);
  },

  delete<T = any>(path: string, config: ApiRequestConfig = {}) {
    return request<T>("DELETE", path, undefined, config);
  },
};

export default api;
