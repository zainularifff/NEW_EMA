import api, { unwrapData, type QueryParams } from "./apiClient";

export type ManagementDashboardLevel = "2" | "3" | 2 | 3;

export type ManagementDashboardDrilldownParams = QueryParams & {
  area?: string;
  key?: string;
  level?: ManagementDashboardLevel;
};

export async function getOverview<T = unknown>(): Promise<T> {
  const payload = await api.get("/api/management-dashboard/overview");
  return unwrapData<T>(payload, {} as T);
}

export async function getStorytelling<T = unknown>(): Promise<T> {
  const payload = await api.get("/api/management-dashboard/storytelling");
  return unwrapData<T>(payload, payload as T);
}

export async function refreshStorytelling<T = unknown>(params?: QueryParams): Promise<T> {
  const payload = await api.post("/api/management-dashboard/storytelling/refresh", params || {});
  return unwrapData<T>(payload, payload as T);
}

export async function getDrilldown<T = unknown>(params?: ManagementDashboardDrilldownParams): Promise<T> {
  const payload = await api.get("/api/management-dashboard/drilldown", { params });
  return unwrapData<T>(payload, payload as T);
}

export async function loadInitialData() {
  const [overview, storytelling] = await Promise.all([
    getOverview(),
    getStorytelling().catch(() => null),
  ]);

  return { overview, storytelling };
}

// Backward-compatible names for existing imports elsewhere.
export const getManagementDashboardOverview = getOverview;
export const getManagementDashboardStorytelling = getStorytelling;
export const refreshManagementDashboardStorytelling = refreshStorytelling;
export const getManagementDashboardDrilldown = getDrilldown;

export default {
  getOverview,
  getStorytelling,
  refreshStorytelling,
  getDrilldown,
  loadInitialData,
  getManagementDashboardOverview,
  getManagementDashboardStorytelling,
  refreshManagementDashboardStorytelling,
  getManagementDashboardDrilldown,
};
