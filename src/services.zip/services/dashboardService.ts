import api, { unwrapData } from "./apiClient";

export async function getDashboardItOperations(mode?: string) {
  const payload = await api.get("/api/dashboard/it-operations", { params: { mode } });
  return unwrapData(payload, {});
}

export async function getDashboardStorytelling() {
  const payload = await api.get("/api/management-dashboard/storytelling");
  return unwrapData(payload, payload);
}

export async function loadInitialData() {
  const [itOperations, storytelling] = await Promise.all([
    getDashboardItOperations("fast"),
    getDashboardStorytelling().catch(() => null),
  ]);

  return { itOperations, storytelling };
}

export default {
  getDashboardItOperations,
  getDashboardStorytelling,
  loadInitialData,
};
